DROP TABLE IF EXISTS chunk_uploads;
DROP TABLE IF EXISTS backup_sessions;
DROP TABLE IF EXISTS files;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS schema_migrations;
