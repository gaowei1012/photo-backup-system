-- Photo Backup System 初始 Schema
-- 用户数据按 user_id 完全隔离；同一用户内以 file_hash 去重。

CREATE TABLE IF NOT EXISTS schema_migrations (
    version VARCHAR(64) PRIMARY KEY,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 用户表
CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(128) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    storage_quota BIGINT DEFAULT 0,
    used_storage BIGINT DEFAULT 0,
    status SMALLINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 文件表（每个用户独立存储，UNIQUE(user_id, file_hash) 实现增量去重）
CREATE TABLE IF NOT EXISTS files (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    file_hash VARCHAR(64) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(512) NOT NULL,
    file_size BIGINT NOT NULL,
    mime_type VARCHAR(64),
    width INTEGER,
    height INTEGER,
    duration INTEGER,
    taken_at TIMESTAMP,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    thumbnail_path VARCHAR(512),
    UNIQUE(user_id, file_hash)
);

CREATE INDEX IF NOT EXISTS idx_files_user_hash ON files(user_id, file_hash);
CREATE INDEX IF NOT EXISTS idx_files_taken_at ON files(taken_at);
CREATE INDEX IF NOT EXISTS idx_files_uploaded_at ON files(uploaded_at);
CREATE INDEX IF NOT EXISTS idx_files_user_id ON files(user_id);

-- 备份会话表
CREATE TABLE IF NOT EXISTS backup_sessions (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_id VARCHAR(64) UNIQUE NOT NULL,
    total_files INTEGER DEFAULT 0,
    uploaded_files INTEGER DEFAULT 0,
    status VARCHAR(20) DEFAULT 'running',
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON backup_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_status ON backup_sessions(status);

-- 分片上传会话（断点续传）
CREATE TABLE IF NOT EXISTS chunk_uploads (
    id BIGSERIAL PRIMARY KEY,
    upload_id VARCHAR(64) UNIQUE NOT NULL,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    file_hash VARCHAR(64) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_size BIGINT NOT NULL,
    mime_type VARCHAR(64),
    chunk_size BIGINT NOT NULL,
    total_chunks INTEGER NOT NULL,
    received_bitmap BYTEA,
    width INTEGER,
    height INTEGER,
    duration INTEGER,
    taken_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_chunk_uploads_user ON chunk_uploads(user_id);
CREATE INDEX IF NOT EXISTS idx_chunk_uploads_hash ON chunk_uploads(user_id, file_hash);
